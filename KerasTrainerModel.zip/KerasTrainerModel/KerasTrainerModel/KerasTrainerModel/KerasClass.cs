﻿using Keras.Datasets;
using Keras.Layers;
using Keras.Models;
using Keras.Utils;
using Numpy;
using System;
using System.IO;
using System.Linq;

namespace KerasTrainerModel
{
    class KerasClass
    {
        public void TrainModel()
        {
            int batch_size = 1000;   
            int num_classes = 10;    

            int epochs = 30;         

            // input image dimensions
            int img_rows = 28, img_cols = 28;

            // the data, split between train and test sets
            var ((x_train, y_train), (x_test, y_test)) =
                                     FashionMNIST.LoadData(); 

            x_train.reshape(-1, img_rows, img_cols).astype(np.float32); 

            y_train = Util.ToCategorical(y_train, num_classes); 

            y_test = Util.ToCategorical(y_test, num_classes);   


            var model = new Sequential();

            model.Add(new Dense(100, 784, "sigmoid")); 

            model.Add(new Dense(10, null, "sigmoid")); 
            model.Compile(optimizer: "sgd", loss: "categorical_crossentropy",
               metrics: new string[] { "accuracy" }); 


            var X_train = x_train.reshape(60000, 784); 

            var X_test = x_test.reshape(10000, 784);

            model.Fit(X_train, y_train, batch_size, epochs, 1); 

            Console.WriteLine("---------------------");
            Console.WriteLine(X_train.shape);
            Console.WriteLine(X_test.shape);
            Console.WriteLine(y_train[0]);
            Console.WriteLine(y_train[1]);       

            var y_train_pred = model.Predict(X_train);       //prediction on the train data
            Console.WriteLine(y_train_pred);

            model.Evaluate(X_test.reshape(-1, 784), y_test); 
                                                             
        }

        private byte[] openDatas(string path, int skip)      
        {
            var file = File.ReadAllBytes(path).Skip(skip).ToArray();
            return file;
        }
    }
}