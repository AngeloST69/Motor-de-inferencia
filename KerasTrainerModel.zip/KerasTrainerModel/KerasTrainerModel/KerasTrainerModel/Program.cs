﻿using System;

namespace KerasTrainerModel
{
    class MainModel
    {
        static void Main(string[] args)
        {
            //KerasClass keras = new KerasClass();
            //keras.TrainModel();

            KerasClassTwo kerasExample = new KerasClassTwo();
            kerasExample.TrainModelTwo();
        }
    }
}
